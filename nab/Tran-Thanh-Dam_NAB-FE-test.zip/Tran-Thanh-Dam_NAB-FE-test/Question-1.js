/*
* Question 1:
* Check if a singly-linked-list of integers is a palindrome (looks the same when reading forward or backward) or not.
* You are allowed to modify links, or update node values, but not adding more nodes. Besides the list,
* you are only allowed to use O(1) extra space.
* Can you do this without scanning the entire list more than 3 times?
* */


/* -- Answer -- */

// Check palindrome function
function isPalindrome(nodeList) {


    let head = nodeList.head

    let current = nodeList.head

    const size = nodeList.size

    let flag = true

    const middleNumber = (size % 2 === 0) ? (size / 2) : ((size + 1) / 2)

    for (let i = 1; i < middleNumber; i++) {
        current = current.next
    }

    let revHead = reverseList(current.next)

    while (head != null && revHead != null) {

        if (head.value !== revHead.value) {
            flag = false
            break
        }

        head = head.next

        revHead = revHead.next
    }

    return flag
}

function reverseList(head) {
    current = head
    prev = null
    next = null

    while (current != null) {
        next = current.next
        current.next = prev
        prev = current
        current = next
    }

    return prev
}

/** ------ Testing ------- **/

// Create singly-linked-list function
function LinkedList() {
    this.head = null;
    this.size = 0;
}

LinkedList.prototype.addValue = function (number) {

    const node = {
        value: number,
        next: null
    }

    this.size++;

    if (!this.head)
        this.head = node;
    else {
        current = this.head;
        while (current.next) {
            current = current.next;
        }
        current.next = node;
    }
}

// Init and create a singly-linked-list
const linkedList = new LinkedList()

// Push value for the singly-linked-list
linkedList.addValue(7)
linkedList.addValue(1)
linkedList.addValue(2)
linkedList.addValue(1)
linkedList.addValue(7)


const result = isPalindrome(linkedList)

console.log(result)
/*
Question 3:
Given a singly-linked-list of N objects; N is unknown in advance.
Only visit each object of the list at most once, can you randomly select an object from the list so that
the probabilities of each object being selected are all equal, i.e. exactly 1/N?
You are only allowed to use a standard random number generator available in your programming language of choice,
and, besides the list, only use O(1) extra space.
* */


/* -- Answer -- */

// Get ramdom node from link-list
function getRandomItem(list){
  // Get the first node
  let current = list.head

  let selected = current

  for(let i = 2; current !== null; i++){

    // 1/N probability
    if((Math.floor(Math.random() * 10)) % i == 0)
      selected = current

    current = current.next
  }

  return selected
}


/** ------ Testing ------- **/

// Create singly-linked-list function
function LinkedList() {
  this.head = null
  this.size = 0
}

LinkedList.prototype.addValue = function (number) {

  const node = {
    value: number,
    next: null
  }

  this.size++;

  if (!this.head)
    this.head = node
  else {
    current = this.head;
    while (current.next) {
      current = current.next;
    }
    current.next = node;
  }
}

// Init and create a singly-linked-list
const linkedList = new LinkedList()

// Push value for the singly-linked-list
linkedList.addValue(7)
linkedList.addValue(1)
linkedList.addValue(2)
linkedList.addValue(1)
linkedList.addValue(7)

const selected = getRandomItem(linkedList)

console.log(selected)


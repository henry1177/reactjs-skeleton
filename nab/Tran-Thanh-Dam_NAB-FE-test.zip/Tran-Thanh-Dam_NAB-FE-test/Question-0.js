

/*
* Question 0:
* List out ​ALL​ the languages and frameworks/libraries that you have worked with,
* and rate each skill on a 10-point-scale on how confident you are with it.
* The following requirements ​must also be​ on this list.
* */


/* -- Answer -- */
/*

Framework - Node.js - 1/10

Language - ECMAScript/CommonJS - 7/10

Babel - 5/10

Framework - React - 8/10

Framework - Redux - 7/10

Language - HTML5/HTML/XHTML - 9/10

Language - CSS3 - 8/10

Language - SASS/LESS - 8/10

Framework - Bootstrap - 8/10

Framework - jQuery, AJAX - 8/10

Framework - jQuery UI - 6/10

Responsive/adaptive layouts - 8/10

Cross-browser compatibility - 8/10

Framework - Material Design - 6.5/10

Framework - Mobx - 6/10

Framework - Mobx State Tree - 4/10

Webpack - 6/10

Gulp - 6/10

Language - PHP - 8/10

Framework - Phalcon PHP - 8/10

Framework - Laravel - 7/10

Language - MySQL - 6/10

Sphinx - 5/10

Elastic Search - 4/10

Redis - 4/10

*/
/*
* Question 2:
* Consider an array of integers wherein the value of each element is +1 or -1 its preceding element.
* Given a number, find the first occurrence (index) of this number in this array without using linear search.
* If cannot find the number, return -1.
* */


/* -- Answer -- */

const integerArray = [4, 5, 6, 5, 6, 7, 8, 9, 10, 9, 10]

function getNumberIndexInArray(number, array) {
    return Array.isArray(array) ? array.findIndex(n => n === number) : -1
}

/** ------ Testing ------- **/

const testNumber = 10

const index = getNumberIndexInArray(testNumber, integerArray)

console.log(index)